# kubernetes-project
this is a testing Kubernetes project for a Django todo app
